"""
this file will extract the feature map from Faster-RCNN
Basically, this feature map will concat with DeepSort, which needs

But what the fuck DeepSort need feature map dim??????

"""