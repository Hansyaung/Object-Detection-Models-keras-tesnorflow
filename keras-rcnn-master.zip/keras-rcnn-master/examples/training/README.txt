.. _training:

Training
--------
