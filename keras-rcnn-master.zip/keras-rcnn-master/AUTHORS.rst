keras-rcnn was written by Allen Goodman.

keras-rcnn is maintained by Allen Goodman and various contributors:

Claire McQuin <mcquincl@gmail.com> @mcquin

Hans Gaiser <j.c.gaiser@delftrobotics.com> @hgaiser

Jane Hung <jyenhung@gmail.com> @jhung0

Jihong Ju <daniel.jihong.ju@gmail.com> @jujihong

Mihai Morariu <mihaimorariu@gmail.com> @mihaimorariu

Robert Harrington <robert.harrington@tessella.com> @harrd-tessella

Victor Kulikovv <v.kulikov@skoltech.ru>

Yann Henon <yannhenon@gmail.com> @yhenon
