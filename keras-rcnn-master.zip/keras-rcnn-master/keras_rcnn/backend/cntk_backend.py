# -*- coding: utf-8 -*-


def argsort(x, **kwargs):
    raise NotImplementedError


def meshgrid(*nargs, **kwargs):
    raise NotImplementedError


def pad(x, pad_width, mode, **kwargs):
    raise NotImplementedError


def shuffle(x):
    raise NotImplementedError


def squeeze(x, axis=None):
    raise NotImplementedError


def transpose(x, axes=None):
    raise NotImplementedError


def unique(x, return_index=False, **kwargs):
    raise NotImplementedError


def where(condition, x=None, y=None):
    raise NotImplementedError
