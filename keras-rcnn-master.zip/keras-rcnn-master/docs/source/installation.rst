Installation
############

You can install Keras-RCNN with pip::

  pip install keras-rcnn

You can also manually compile Keras-RCNN::

  pip install git+https://github.com/broadinstitute/keras-rcnn.git
