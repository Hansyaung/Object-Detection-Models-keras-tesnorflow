Preprocessing
#############

ObjectDetectionGenerator
========================

.. autoclass:: keras_rcnn.preprocessing.ObjectDetectionGenerator
