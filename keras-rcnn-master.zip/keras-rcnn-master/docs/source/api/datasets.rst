Datasets
########

Malaria
=======

.. autofunction:: keras_rcnn.datasets.malaria.load_data

PASCAL
======

.. autofunction:: keras_rcnn.datasets.pascal.load_data

Shape
=====

.. autofunction:: keras_rcnn.datasets.shape.load_data
