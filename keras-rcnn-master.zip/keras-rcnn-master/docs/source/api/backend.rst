Backend
#######

.. autofunction:: keras_rcnn.backend.argsort

.. autofunction:: keras_rcnn.backend.meshgrid

.. autofunction:: keras_rcnn.backend.pad

.. autofunction:: keras_rcnn.backend.shuffle

.. autofunction:: keras_rcnn.backend.squeeze

.. autofunction:: keras_rcnn.backend.transpose

.. autofunction:: keras_rcnn.backend.unique

.. autofunction:: keras_rcnn.backend.where
